import os
import pandas as pd


# ============================================================
# PROJECT
# ============================================================

PROJECT = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        ".."
    )
)

VIDEO_ROOT = os.path.join(
    PROJECT,
    "data",
    "videos"
)

META_ROOT = os.path.join(
    PROJECT,
    "metadata"
)


print(
    "Project:",
    PROJECT
)

print(
    "Videos:",
    VIDEO_ROOT
)


# ============================================================
# CHECK EACH SPLIT
# ============================================================

for split in [
    "train",
    "val",
    "test"
]:

    csv_path = os.path.join(
        META_ROOT,
        f"{split}_24.csv"
    )

    if not os.path.isfile(
        csv_path
    ):

        print(
            f"{split}: metadata missing"
        )

        continue


    df = pd.read_csv(
        csv_path
    )

    found = 0
    missing = 0


    for rel in df["video_path"]:

        path = os.path.join(
            VIDEO_ROOT,
            str(rel)
        )

        if os.path.isfile(path):

            found += 1

        else:

            missing += 1


    print(
        f"{split}: "
        f"found={found}, "
        f"missing={missing}, "
        f"total={len(df)}"
    )