# ============================================================
# test_static.py
#
# STATIC / CLIP-BASED ISL SIGN TEST
#
# 1. Opens webcam
# 2. Captures a short clip
# 3. Automatically stops capture
# 4. Processes the captured frames
# 5. Runs ONE prediction
# 6. Shows the result on screen
#
# MODEL:
#   40 x 900 -> 22 classes
# ============================================================

import os
import time
import cv2
import numpy as np
import tensorflow as tf
import mediapipe as mp


# ============================================================
# 1. PROJECT PATHS
# ============================================================

PROJECT = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        ".."
    )
)

MODEL = os.path.join(
    PROJECT,
    "models",
    "isl_20plus_final.tflite"
)

CLASSES = os.path.join(
    PROJECT,
    "models",
    "classes.txt"
)

FEATURE_MEAN = os.path.join(
    PROJECT,
    "models",
    "feature_mean.npy"
)

FEATURE_STD = os.path.join(
    PROJECT,
    "models",
    "feature_std.npy"
)


# ============================================================
# 2. SETTINGS
# ============================================================

SEQ_LEN = 40
RAW_FEATURES = 258
ENHANCED_FEATURES = 900

CAPTURE_SECONDS = 3.0

CONFIDENCE_THRESHOLD = 0.40


# ============================================================
# 3. CHECK FILES
# ============================================================

for path in [
    MODEL,
    CLASSES,
    FEATURE_MEAN,
    FEATURE_STD
]:

    if not os.path.isfile(path):

        raise FileNotFoundError(
            f"Required file not found:\n{path}"
        )


# ============================================================
# 4. LOAD CLASSES
# ============================================================

classes = []

with open(
    CLASSES,
    "r",
    encoding="utf-8"
) as f:

    for line in f:

        line = line.strip()

        if not line:
            continue

        _, label = line.split(
            "\t",
            1
        )

        classes.append(
            label
        )


# ============================================================
# 5. LOAD NORMALIZATION PARAMETERS
# ============================================================

feature_mean = np.load(
    FEATURE_MEAN
).astype(
    np.float32
)

feature_std = np.load(
    FEATURE_STD
).astype(
    np.float32
)

feature_std = np.where(
    feature_std < 1e-6,
    1.0,
    feature_std
).astype(
    np.float32
)


# ============================================================
# 6. LOAD TFLITE MODEL
# ============================================================

interpreter = tf.lite.Interpreter(
    model_path=MODEL
)

interpreter.allocate_tensors()

input_details = (
    interpreter.get_input_details()
)

output_details = (
    interpreter.get_output_details()
)

print(
    "Model input :",
    input_details[0]["shape"]
)

print(
    "Model output:",
    output_details[0]["shape"]
)

print(
    "Classes     :",
    len(classes)
)


if tuple(input_details[0]["shape"]) != (
    1,
    40,
    900
):

    raise ValueError(
        "Wrong model. Expected input [1,40,900]."
    )

if output_details[0]["shape"][-1] != len(classes):

    raise ValueError(
        "Model/classes mismatch."
    )


# ============================================================
# 7. MEDIAPIPE
# ============================================================

mp_holistic = mp.solutions.holistic
mp_draw = mp.solutions.drawing_utils


# ============================================================
# 8. EXTRACT RAW 258 FEATURES
# EXACTLY MATCHES TRAINING
# ============================================================

def extract_raw_features(
    frame,
    holistic
):

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    result = holistic.process(
        rgb
    )

    features = []


    # --------------------------------------------------------
    # POSE = 132
    # --------------------------------------------------------

    if result.pose_landmarks:

        for lm in result.pose_landmarks.landmark:

            features.extend([
                lm.x,
                lm.y,
                lm.z,
                lm.visibility
            ])

    else:

        features.extend(
            [0.0] * 132
        )


    # --------------------------------------------------------
    # LEFT HAND = 63
    # --------------------------------------------------------

    if result.left_hand_landmarks:

        for lm in result.left_hand_landmarks.landmark:

            features.extend([
                lm.x,
                lm.y,
                lm.z
            ])

    else:

        features.extend(
            [0.0] * 63
        )


    # --------------------------------------------------------
    # RIGHT HAND = 63
    # --------------------------------------------------------

    if result.right_hand_landmarks:

        for lm in result.right_hand_landmarks.landmark:

            features.extend([
                lm.x,
                lm.y,
                lm.z
            ])

    else:

        features.extend(
            [0.0] * 63
        )


    features = np.asarray(
        features,
        dtype=np.float32
    )


    # ========================================================
    # SHOULDER NORMALIZATION
    # ========================================================

    if len(features) == 258:

        left_shoulder = features[
            44:47
        ]

        right_shoulder = features[
            48:51
        ]

        center = (
            left_shoulder +
            right_shoulder
        ) / 2.0

        shoulder_distance = np.linalg.norm(
            left_shoulder -
            right_shoulder
        )

        if shoulder_distance > 1e-6:

            # Pose
            for i in range(33):

                base = i * 4

                features[
                    base:base + 3
                ] = (
                    features[
                        base:base + 3
                    ]
                    - center
                ) / shoulder_distance


            # Left hand
            for i in range(21):

                base = 132 + i * 3

                features[
                    base:base + 3
                ] = (
                    features[
                        base:base + 3
                    ]
                    - center
                ) / shoulder_distance


            # Right hand
            for i in range(21):

                base = 195 + i * 3

                features[
                    base:base + 3
                ] = (
                    features[
                        base:base + 3
                    ]
                    - center
                ) / shoulder_distance


    return features, result


# ============================================================
# 9. CAPTURE FROM WEBCAM
# ============================================================

cap = cv2.VideoCapture(0)

if not cap.isOpened():

    raise RuntimeError(
        "Could not open webcam."
    )

cap.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    640
)

cap.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    480
)


print(
    "\n========================================"
)

print(
    "ISL STATIC SIGN TEST"
)

print(
    "========================================"
)

print(
    f"Camera will capture "
    f"{CAPTURE_SECONDS:.1f} seconds."
)

print(
    "Show ONE sign during this time."
)

print(
    "Press Q to cancel."
)


captured_frames = []

start_time = time.time()


# ============================================================
# MEDIAPIPE FOR CAPTURE
# ============================================================

with mp_holistic.Holistic(

    static_image_mode=False,

    model_complexity=1,

    refine_face_landmarks=False,

    min_detection_confidence=0.5,

    min_tracking_confidence=0.5

) as holistic:

    while True:

        ret, frame = cap.read()

        if not ret:

            break


        # Mirror
        frame = cv2.flip(
            frame,
            1
        )


        captured_frames.append(
            frame.copy()
        )


        elapsed = (
            time.time() -
            start_time
        )

        remaining = max(
            0,
            CAPTURE_SECONDS -
            elapsed
        )


        # ----------------------------------------------------
        # DISPLAY CAPTURE STATUS
        # ----------------------------------------------------

        cv2.rectangle(
            frame,
            (10, 10),
            (630, 100),
            (0, 0, 0),
            -1
        )


        cv2.putText(
            frame,
            "CAPTURING SIGN...",
            (25, 45),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (255, 255, 255),
            2
        )


        cv2.putText(
            frame,
            f"{remaining:.1f} sec",
            (25, 82),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )


        cv2.putText(
            frame,
            "Q = cancel",
            (500, 465),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 255, 255),
            2
        )


        cv2.imshow(
            "ISL Static Sign Test",
            frame
        )


        key = cv2.waitKey(1) & 0xFF


        if key == ord("q"):

            cap.release()

            cv2.destroyAllWindows()

            raise SystemExit(
                "Cancelled."
            )


        if elapsed >= CAPTURE_SECONDS:

            break


cap.release()

cv2.destroyAllWindows()


print(
    f"\nCaptured frames: "
    f"{len(captured_frames)}"
)


# ============================================================
# 10. SAMPLE EXACTLY 40 FRAMES
# ============================================================

if len(captured_frames) == 0:

    raise RuntimeError(
        "No frames captured."
    )


indices = np.linspace(
    0,
    len(captured_frames) - 1,
    SEQ_LEN
).astype(int)


selected_frames = [
    captured_frames[i]
    for i in indices
]


# ============================================================
# 11. PROCESS SELECTED FRAMES
# ============================================================

raw_sequence = []

with mp_holistic.Holistic(

    static_image_mode=False,

    model_complexity=1,

    refine_face_landmarks=False,

    min_detection_confidence=0.5,

    min_tracking_confidence=0.5

) as holistic:

    for frame in selected_frames:

        features, _ = extract_raw_features(
            frame,
            holistic
        )

        raw_sequence.append(
            features
        )


raw_sequence = np.asarray(
    raw_sequence,
    dtype=np.float32
)


if raw_sequence.shape != (
    40,
    258
):

    raise RuntimeError(
        f"Bad raw sequence shape: "
        f"{raw_sequence.shape}"
    )


# ============================================================
# 12. CREATE 900 FEATURES
# ============================================================

X = raw_sequence


# ------------------------------------------------------------
# VELOCITY
# ------------------------------------------------------------

velocity = np.diff(
    X,
    axis=0,
    prepend=X[:1]
)


# ------------------------------------------------------------
# ACCELERATION
# ------------------------------------------------------------

acceleration = np.diff(
    velocity,
    axis=0,
    prepend=velocity[:1]
)


# ------------------------------------------------------------
# LEFT HAND
# ------------------------------------------------------------

left_hand = X[
    :,
    132:195
].reshape(
    40,
    21,
    3
)


# ------------------------------------------------------------
# RIGHT HAND
# ------------------------------------------------------------

right_hand = X[
    :,
    195:258
].reshape(
    40,
    21,
    3
)


# ------------------------------------------------------------
# WRIST RELATIVE
# ------------------------------------------------------------

left_relative = (
    left_hand -
    left_hand[:, 0:1, :]
).reshape(
    40,
    63
)


right_relative = (
    right_hand -
    right_hand[:, 0:1, :]
).reshape(
    40,
    63
)


# ------------------------------------------------------------
# COMBINE
# ------------------------------------------------------------

enhanced = np.concatenate(
    [
        X,
        velocity,
        acceleration,
        left_relative,
        right_relative
    ],
    axis=1
)


if enhanced.shape != (
    40,
    900
):

    raise RuntimeError(
        f"Bad enhanced shape: "
        f"{enhanced.shape}"
    )


# ============================================================
# 13. STANDARDIZE
# ============================================================

enhanced = (
    enhanced -
    feature_mean
) / feature_std


enhanced = np.clip(
    enhanced,
    -6,
    6
).astype(
    np.float32
)


# ============================================================
# 14. INFERENCE
# ============================================================

model_input = np.expand_dims(
    enhanced,
    axis=0
)


interpreter.set_tensor(
    input_details[0]["index"],
    model_input
)

interpreter.invoke()


probabilities = (
    interpreter
    .get_tensor(
        output_details[0]["index"]
    )[0]
)


# ============================================================
# 15. BEST PREDICTION
# ============================================================

predicted_id = int(
    np.argmax(
        probabilities
    )
)

confidence = float(
    probabilities[
        predicted_id
    ]
)

predicted_label = classes[
    predicted_id
]


print(
    "\n========================================"
)

print(
    "RESULT"
)

print(
    "========================================"
)

print(
    "SIGN:",
    predicted_label
)

print(
    f"CONFIDENCE: "
    f"{confidence:.2%}"
)


# ============================================================
# 16. TOP 3
# ============================================================

top_ids = np.argsort(
    probabilities
)[::-1][:3]


print(
    "\nTop 3:"
)

for rank, idx in enumerate(
    top_ids,
    1
):

    print(
        f"{rank}. "
        f"{classes[idx]} "
        f"({probabilities[idx]:.2%})"
    )


# ============================================================
# 17. SHOW RESULT
# ============================================================

# Show the middle captured frame
display_frame = captured_frames[
    len(captured_frames) // 2
].copy()


cv2.rectangle(
    display_frame,
    (10, 10),
    (630, 120),
    (0, 0, 0),
    -1
)


if confidence >= CONFIDENCE_THRESHOLD:

    shown_label = predicted_label

else:

    shown_label = "Uncertain"


cv2.putText(
    display_frame,
    "ISL SIGN:",
    (25, 48),
    cv2.FONT_HERSHEY_SIMPLEX,
    0.8,
    (255, 255, 255),
    2
)


cv2.putText(
    display_frame,
    shown_label,
    (180, 48),
    cv2.FONT_HERSHEY_SIMPLEX,
    0.8,
    (255, 255, 255),
    2
)


cv2.putText(
    display_frame,
    f"Confidence: "
    f"{confidence:.2%}",
    (25, 88),
    cv2.FONT_HERSHEY_SIMPLEX,
    0.7,
    (255, 255, 255),
    2
)


cv2.putText(
    display_frame,
    "Prediction complete",
    (410, 88),
    cv2.FONT_HERSHEY_SIMPLEX,
    0.55,
    (255, 255, 255),
    2
)


# ============================================================
# SHOW RESULT WINDOW
# ============================================================

cv2.imshow(
    "ISL Static Prediction",
    display_frame
)


print(
    "\nPrediction window opened."
)

print(
    "Press any key inside the window to close."
)


cv2.waitKey(0)

cv2.destroyAllWindows()