import os
import time
import requests
from tqdm import tqdm


# ============================================================
# SETTINGS
# ============================================================

PROJECT = r"D:\capstone\isl_conversational_model"

DOWNLOAD_DIR = os.path.join(
    PROJECT,
    "data",
    "archives"
)

os.makedirs(
    DOWNLOAD_DIR,
    exist_ok=True
)


# ============================================================
# DIRECT ZENODO FILE URLS
# ============================================================

BASE_URL = (
    "https://zenodo.org/records/4010759/files"
)


REQUIRED = [

    "Greetings_1of2.zip",
    "Greetings_2of2.zip",

    "Days_and_Time_1of3.zip",
    "Days_and_Time_2of3.zip",
    "Days_and_Time_3of3.zip",

    "Pronouns_1of2.zip",
    "Pronouns_2of2.zip"
]


MAX_RETRIES = 20

CHUNK_SIZE = 16 * 1024 * 1024   # 16 MB


# ============================================================
# DOWNLOAD ONE FILE
# ============================================================

def download_file(filename):

    path = os.path.join(
        DOWNLOAD_DIR,
        filename
    )

    url = (
        f"{BASE_URL}/"
        f"{filename}?download=1"
    )


    for attempt in range(
        1,
        MAX_RETRIES + 1
    ):

        existing = (
            os.path.getsize(path)
            if os.path.exists(path)
            else 0
        )


        print(
            "\n" + "=" * 70
        )

        print(
            f"{filename}"
        )

        print(
            f"Attempt {attempt}/{MAX_RETRIES}"
        )

        print(
            "=" * 70
        )


        try:

            # ------------------------------------------------
            # REQUEST
            # ------------------------------------------------

            headers = {}

            if existing > 0:

                print(
                    f"Resuming from "
                    f"{existing / (1024**3):.2f} GB"
                )

                headers["Range"] = (
                    f"bytes={existing}-"
                )

            else:

                print(
                    "Starting download..."
                )


            with requests.get(
                url,
                headers=headers,
                stream=True,
                timeout=(30, 180)
            ) as response:

                # ------------------------------------------------
                # HANDLE RESUME
                # ------------------------------------------------

                if (
                    existing > 0
                    and response.status_code == 200
                ):

                    print(
                        "Server ignored Range request."
                    )

                    print(
                        "Restarting this file."
                    )

                    existing = 0

                    mode = "wb"

                elif response.status_code == 206:

                    mode = "ab"

                else:

                    response.raise_for_status()

                    mode = "wb"


                # ------------------------------------------------
                # GET TOTAL SIZE
                # ------------------------------------------------

                content_length = response.headers.get(
                    "Content-Length"
                )

                if content_length:

                    content_length = int(
                        content_length
                    )

                    total_size = (
                        existing +
                        content_length
                        if mode == "ab"
                        else content_length
                    )

                else:

                    total_size = None


                # ------------------------------------------------
                # WRITE
                # ------------------------------------------------

                with open(
                    path,
                    mode
                ) as f:

                    with tqdm(
                        total=total_size,
                        initial=existing,
                        unit="B",
                        unit_scale=True,
                        unit_divisor=1024,
                        desc=filename
                    ) as bar:

                        for chunk in response.iter_content(
                            chunk_size=CHUNK_SIZE
                        ):

                            if not chunk:
                                continue

                            f.write(chunk)

                            bar.update(
                                len(chunk)
                            )


            # ------------------------------------------------
            # SUCCESS
            # ------------------------------------------------

            final_size = os.path.getsize(
                path
            )

            print(
                f"\n✅ Downloaded "
                f"{final_size / (1024**3):.2f} GB"
            )

            return True


        except (
            requests.exceptions.ChunkedEncodingError,
            requests.exceptions.ConnectionError,
            requests.exceptions.Timeout,
            requests.exceptions.ProtocolError
        ) as e:

            print(
                "\n⚠️ Connection interrupted:"
            )

            print(
                str(e)
            )

            if os.path.exists(path):

                saved = os.path.getsize(
                    path
                )

                print(
                    f"Saved locally: "
                    f"{saved / (1024**3):.2f} GB"
                )

            print(
                "Retrying in 5 seconds..."
            )

            time.sleep(5)


        except requests.exceptions.HTTPError as e:

            print(
                "\n⚠️ HTTP error:"
            )

            print(
                str(e)
            )

            print(
                "Retrying in 10 seconds..."
            )

            time.sleep(10)


        except Exception as e:

            print(
                "\n⚠️ Unexpected error:"
            )

            print(
                repr(e)
            )

            print(
                "Retrying in 10 seconds..."
            )

            time.sleep(10)


    print(
        f"\n❌ Failed: {filename}"
    )

    return False


# ============================================================
# DOWNLOAD ALL 7
# ============================================================

for i, filename in enumerate(
    REQUIRED,
    start=1
):

    print(
        f"\n\n[{i}/{len(REQUIRED)}]"
    )

    success = download_file(
        filename
    )

    if not success:

        print(
            "\nStopping."
        )

        print(
            "Run the script again later."
        )

        break


# ============================================================
# SUMMARY
# ============================================================

print(
    "\n" + "=" * 70
)

print(
    "DOWNLOAD SUMMARY"
)

print(
    "=" * 70
)

for filename in REQUIRED:

    path = os.path.join(
        DOWNLOAD_DIR,
        filename
    )

    if os.path.exists(path):

        size_gb = (
            os.path.getsize(path)
            /
            (1024**3)
        )

        print(
            f"{filename:35s}"
            f"{size_gb:7.2f} GB"
        )

    else:

        print(
            f"{filename:35s}"
            f" NOT DOWNLOADED"
        )