# ============================================================
# CONTINUOUS REAL-TIME ISL RECOGNITION
# Revised version:
# - Exact 258 -> 900 feature pipeline
# - 40-frame rolling window
# - Continuous inference
# - Hand-presence detection
# - Proper state reset
# - Fast class switching
# - No permanent "stuck" prediction
# ============================================================

import os
import json
import time
from collections import deque

import cv2
import numpy as np
import mediapipe as mp
import tensorflow as tf


# ============================================================
# PROJECT PATH
# ============================================================

ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)

MODEL_PATH = os.path.join(
    ROOT, "models", "isl_20plus_final.tflite"
)

CLASSES_PATH = os.path.join(
    ROOT, "models", "classes.txt"
)

MEAN_PATH = os.path.join(
    ROOT, "models", "feature_mean.npy"
)

STD_PATH = os.path.join(
    ROOT, "models", "feature_std.npy"
)

PREPROCESS_PATH = os.path.join(
    ROOT, "models", "preprocessing.json"
)


# ============================================================
# SETTINGS
# ============================================================

SEQUENCE_LENGTH = 40

# Infer every N webcam frames
INFERENCE_EVERY = 3

# Minimum confidence to accept a prediction
CONFIDENCE_THRESHOLD = 0.35

# Number of SAME consecutive predictions needed
# before changing the displayed sign.
#
# Smaller = faster response
# Larger = more stable
STABLE_REQUIRED = 2

# How many consecutive frames without a hand
# will reset the recognition state.
NO_HAND_RESET_FRAMES = 8

# Camera
CAMERA_INDEX = 0


# ============================================================
# LOAD MODEL
# ============================================================

print("=" * 65)
print("ISL CONTINUOUS REAL-TIME RECOGNITION")
print("=" * 65)

print("\nLoading model...")

interpreter = tf.lite.Interpreter(
    model_path=MODEL_PATH
)

interpreter.allocate_tensors()

input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

print("Input :", input_details[0]["shape"])
print("Output:", output_details[0]["shape"])


# ============================================================
# LOAD CLASSES
# ============================================================

with open(
    CLASSES_PATH,
    "r",
    encoding="utf-8"
) as f:

    classes = [
        line.strip()
        for line in f
        if line.strip()
    ]

print("Classes:", len(classes))


# ============================================================
# LOAD NORMALIZATION
# ============================================================

feature_mean = np.load(
    MEAN_PATH
).astype(np.float32)

feature_std = np.load(
    STD_PATH
).astype(np.float32)

feature_std = np.where(
    feature_std < 1e-6,
    1.0,
    feature_std
)

print("Mean shape:", feature_mean.shape)
print("Std shape :", feature_std.shape)


# ============================================================
# LOAD PREPROCESSING CONFIG
# ============================================================

if os.path.exists(PREPROCESS_PATH):

    with open(
        PREPROCESS_PATH,
        "r",
        encoding="utf-8"
    ) as f:

        preprocessing_config = json.load(f)

    print("\nPreprocessing configuration loaded.")


# ============================================================
# MEDIAPIPE
# ============================================================

mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils


# ============================================================
# RAW FEATURE EXTRACTION
# ============================================================

def extract_raw_features(results):

    # --------------------------------------------------------
    # POSE
    # 33 landmarks × 4 = 132
    # --------------------------------------------------------

    if results.pose_landmarks:

        pose = []

        for lm in results.pose_landmarks.landmark:

            pose.extend([
                lm.x,
                lm.y,
                lm.z,
                lm.visibility
            ])

    else:

        pose = [0.0] * 132


    # --------------------------------------------------------
    # LEFT HAND
    # 21 × 3 = 63
    # --------------------------------------------------------

    if results.left_hand_landmarks:

        left_hand = []

        for lm in results.left_hand_landmarks.landmark:

            left_hand.extend([
                lm.x,
                lm.y,
                lm.z
            ])

    else:

        left_hand = [0.0] * 63


    # --------------------------------------------------------
    # RIGHT HAND
    # 21 × 3 = 63
    # --------------------------------------------------------

    if results.right_hand_landmarks:

        right_hand = []

        for lm in results.right_hand_landmarks.landmark:

            right_hand.extend([
                lm.x,
                lm.y,
                lm.z
            ])

    else:

        right_hand = [0.0] * 63


    features = np.array(
        pose + left_hand + right_hand,
        dtype=np.float32
    )

    if features.shape[0] != 258:

        raise ValueError(
            f"Expected 258 features, "
            f"got {features.shape[0]}"
        )

    return features


# ============================================================
# HAND PRESENCE
# ============================================================

def hand_present(results):

    return (
        results.left_hand_landmarks is not None
        or
        results.right_hand_landmarks is not None
    )


# ============================================================
# ENHANCE 258 -> 900
# ============================================================

def enhance_sequence(sequence):

    sequence = np.asarray(
        sequence,
        dtype=np.float32
    )

    # --------------------------------------------------------
    # RAW
    # 258
    # --------------------------------------------------------

    raw = sequence.copy()


    # --------------------------------------------------------
    # VELOCITY
    # 258
    # --------------------------------------------------------

    velocity = np.zeros_like(sequence)

    if len(sequence) > 1:

        velocity[1:] = (
            sequence[1:]
            -
            sequence[:-1]
        )


    # --------------------------------------------------------
    # ACCELERATION
    # 258
    # --------------------------------------------------------

    acceleration = np.zeros_like(sequence)

    if len(velocity) > 1:

        acceleration[1:] = (
            velocity[1:]
            -
            velocity[:-1]
        )


    # --------------------------------------------------------
    # LEFT HAND RELATIVE TO WRIST
    # 63
    # --------------------------------------------------------

    left = sequence[:, 132:195]

    left = left.reshape(
        len(sequence),
        21,
        3
    )

    left_wrist = left[:, 0:1, :]

    left_relative = (
        left - left_wrist
    )

    left_relative = left_relative.reshape(
        len(sequence),
        63
    )


    # --------------------------------------------------------
    # RIGHT HAND RELATIVE TO WRIST
    # 63
    # --------------------------------------------------------

    right = sequence[:, 195:258]

    right = right.reshape(
        len(sequence),
        21,
        3
    )

    right_wrist = right[:, 0:1, :]

    right_relative = (
        right - right_wrist
    )

    right_relative = right_relative.reshape(
        len(sequence),
        63
    )


    # --------------------------------------------------------
    # COMBINE
    # --------------------------------------------------------

    enhanced = np.concatenate(
        [
            raw,
            velocity,
            acceleration,
            left_relative,
            right_relative
        ],
        axis=1
    )


    if enhanced.shape[1] != 900:

        raise ValueError(
            f"Expected 900 features, "
            f"got {enhanced.shape[1]}"
        )

    return enhanced.astype(np.float32)


# ============================================================
# STANDARDIZATION
# ============================================================

def standardize_sequence(sequence):

    sequence = (
        sequence - feature_mean
    ) / feature_std

    sequence = np.clip(
        sequence,
        -6.0,
        6.0
    )

    return sequence.astype(np.float32)


# ============================================================
# MODEL PREDICTION
# ============================================================

def predict(sequence):

    enhanced = enhance_sequence(
        sequence
    )

    normalized = standardize_sequence(
        enhanced
    )

    model_input = np.expand_dims(
        normalized,
        axis=0
    )


    # --------------------------------------------------------
    # TFLITE
    # --------------------------------------------------------

    interpreter.set_tensor(
        input_details[0]["index"],
        model_input
    )

    interpreter.invoke()

    output = interpreter.get_tensor(
        output_details[0]["index"]
    )[0]

    probabilities = output.astype(
        np.float32
    )


    # Safety normalization
    total = probabilities.sum()

    if total > 0:

        probabilities /= total


    top_index = int(
        np.argmax(probabilities)
    )

    confidence = float(
        probabilities[top_index]
    )

    return (
        top_index,
        confidence,
        probabilities
    )


# ============================================================
# DRAW LANDMARKS
# ============================================================

def draw_landmarks(frame, results):

    if results.pose_landmarks:

        mp_drawing.draw_landmarks(
            frame,
            results.pose_landmarks,
            mp_holistic.POSE_CONNECTIONS
        )

    if results.left_hand_landmarks:

        mp_drawing.draw_landmarks(
            frame,
            results.left_hand_landmarks,
            mp_holistic.HAND_CONNECTIONS
        )

    if results.right_hand_landmarks:

        mp_drawing.draw_landmarks(
            frame,
            results.right_hand_landmarks,
            mp_holistic.HAND_CONNECTIONS
        )


# ============================================================
# OPEN CAMERA
# ============================================================

cap = cv2.VideoCapture(
    CAMERA_INDEX
)

if not cap.isOpened():

    raise RuntimeError(
        "Could not open webcam."
    )


cap.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    1280
)

cap.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    720
)

cap.set(
    cv2.CAP_PROP_FPS,
    30
)


# ============================================================
# BUFFERS
# ============================================================

sequence_buffer = deque(
    maxlen=SEQUENCE_LENGTH
)


# ============================================================
# RECOGNITION STATE
# ============================================================

display_label = "Waiting for sign..."

display_confidence = 0.0

candidate_label = None

candidate_count = 0

last_prediction = None
last_prediction_confidence = 0.0

no_hand_count = 0


# ============================================================
# FPS
# ============================================================

fps = 0.0
fps_start = time.time()
fps_frames = 0

frame_number = 0


# ============================================================
# START CAMERA
# ============================================================

print("\nCamera started.")
print("Press Q to quit.")
print("Show one sign at a time.\n")


# ============================================================
# MEDIAPIPE HOLISTIC
# ============================================================

with mp_holistic.Holistic(

    static_image_mode=False,

    model_complexity=1,

    smooth_landmarks=True,

    enable_segmentation=False,

    refine_face_landmarks=False,

    min_detection_confidence=0.5,

    min_tracking_confidence=0.5

) as holistic:


    # ========================================================
    # MAIN LOOP
    # ========================================================

    while True:

        ret, frame = cap.read()

        if not ret:

            print(
                "Could not read webcam frame."
            )

            break


        frame_number += 1
        fps_frames += 1


        # ----------------------------------------------------
        # MIRROR
        # ----------------------------------------------------

        frame = cv2.flip(
            frame,
            1
        )


        # ----------------------------------------------------
        # RGB
        # ----------------------------------------------------

        rgb = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2RGB
        )

        rgb.flags.writeable = False

        results = holistic.process(
            rgb
        )

        rgb.flags.writeable = True


        # ----------------------------------------------------
        # DRAW LANDMARKS
        # ----------------------------------------------------

        draw_landmarks(
            frame,
            results
        )


        # ----------------------------------------------------
        # CHECK HAND
        # ----------------------------------------------------

        has_hand = hand_present(
            results
        )


        if has_hand:

            no_hand_count = 0

        else:

            no_hand_count += 1


        # ====================================================
        # NO HAND -> RESET
        # ====================================================

        if no_hand_count >= NO_HAND_RESET_FRAMES:

            sequence_buffer.clear()

            candidate_label = None

            candidate_count = 0

            display_label = (
                "Waiting for sign..."
            )

            display_confidence = 0.0

            last_prediction = None

            last_prediction_confidence = 0.0


        # ====================================================
        # EXTRACT FEATURES
        # ====================================================

        features = extract_raw_features(
            results
        )

        sequence_buffer.append(
            features
        )


        # ====================================================
        # INFERENCE
        # ====================================================

        if (
            has_hand
            and
            len(sequence_buffer)
            == SEQUENCE_LENGTH
            and
            frame_number % INFERENCE_EVERY == 0
        ):

            sequence = np.asarray(
                sequence_buffer,
                dtype=np.float32
            )


            try:

                (
                    class_index,
                    confidence,
                    probabilities
                ) = predict(
                    sequence
                )

            except Exception as e:

                print(
                    "\nPrediction error:",
                    e
                )

                continue


            predicted_label = classes[
                class_index
            ]


            last_prediction = (
                predicted_label
            )

            last_prediction_confidence = (
                confidence
            )


            # =================================================
            # ACCEPTABLE CONFIDENCE
            # =================================================

            if confidence >= CONFIDENCE_THRESHOLD:


                # ---------------------------------------------
                # SAME AS CURRENT CANDIDATE
                # ---------------------------------------------

                if predicted_label == candidate_label:

                    candidate_count += 1


                # ---------------------------------------------
                # NEW CANDIDATE
                # ---------------------------------------------

                else:

                    candidate_label = (
                        predicted_label
                    )

                    candidate_count = 1


                # ---------------------------------------------
                # STABLE NEW PREDICTION
                # ---------------------------------------------

                if candidate_count >= STABLE_REQUIRED:

                    display_label = (
                        predicted_label
                    )

                    display_confidence = (
                        confidence
                    )


            # =================================================
            # LOW CONFIDENCE
            # =================================================

            else:

                # Do NOT immediately change the label.
                #
                # But if the prediction is very uncertain,
                # stop pretending that the old prediction
                # is still reliable.

                if confidence < 0.25:

                    display_label = (
                        "Uncertain"
                    )

                    display_confidence = (
                        confidence
                    )

                    candidate_label = None
                    candidate_count = 0


        # ====================================================
        # FPS
        # ====================================================

        elapsed = (
            time.time()
            -
            fps_start
        )

        if elapsed >= 1.0:

            fps = (
                fps_frames
                /
                elapsed
            )

            fps_frames = 0
            fps_start = time.time()


        # ====================================================
        # USER INTERFACE
        # ====================================================

        cv2.rectangle(
            frame,
            (0, 0),
            (frame.shape[1], 125),
            (0, 0, 0),
            -1
        )


        # ----------------------------------------------------
        # MAIN LABEL
        # ----------------------------------------------------

        if (
            display_label
            == "Waiting for sign..."
        ):

            main_text = (
                "Waiting for sign..."
            )

        elif (
            display_label
            == "Uncertain"
        ):

            main_text = (
                f"Uncertain "
                f"{display_confidence * 100:.1f}%"
            )

        else:

            main_text = (
                f"{display_label} "
                f"{display_confidence * 100:.1f}%"
            )


        cv2.putText(
            frame,
            main_text,
            (20, 48),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.95,
            (255, 255, 255),
            2
        )


        # ----------------------------------------------------
        # DEBUG: CURRENT RAW MODEL PREDICTION
        # ----------------------------------------------------

        if last_prediction is not None:

            debug_text = (
                f"Model: {last_prediction} "
                f"{last_prediction_confidence * 100:.1f}%"
            )

        else:

            debug_text = (
                "Model: waiting..."
            )


        cv2.putText(
            frame,
            debug_text,
            (20, 78),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (210, 210, 210),
            1
        )


        # ----------------------------------------------------
        # BUFFER
        # ----------------------------------------------------

        cv2.putText(
            frame,
            f"Buffer: "
            f"{len(sequence_buffer)}/"
            f"{SEQUENCE_LENGTH}",
            (20, 103),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (210, 210, 210),
            1
        )


        # ----------------------------------------------------
        # FPS
        # ----------------------------------------------------

        cv2.putText(
            frame,
            f"FPS: {fps:.1f}",
            (
                frame.shape[1] - 130,
                35
            ),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 255, 255),
            2
        )


        # ----------------------------------------------------
        # HAND STATUS
        # ----------------------------------------------------

        hand_status = (
            "HAND DETECTED"
            if has_hand
            else "NO HAND"
        )

        cv2.putText(
            frame,
            hand_status,
            (
                frame.shape[1] - 220,
                65
            ),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (255, 255, 255),
            1
        )


        # ----------------------------------------------------
        # INSTRUCTIONS
        # ----------------------------------------------------

        cv2.putText(
            frame,
            "Press Q to quit",
            (
                20,
                frame.shape[0] - 20
            ),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            1
        )


        # ====================================================
        # SHOW
        # ====================================================

        cv2.imshow(
            "ISL Continuous Recognition",
            frame
        )


        key = (
            cv2.waitKey(1)
            &
            0xFF
        )


        if key == ord("q"):

            break


# ============================================================
# CLEANUP
# ============================================================

cap.release()
cv2.destroyAllWindows()

print("\nWebcam recognition stopped.")