# ============================================================
# test_dataset_video.py
#
# Test the trained 22-class model on ONE actual INCLUDE video.
# This uses the SAME preprocessing as train_model.py:
#
# 258 raw landmarks
# + 258 velocity
# + 258 acceleration
# + 63 left relative
# + 63 right relative
# = 900 features
# ============================================================

import os
import sys
import cv2
import numpy as np
import tensorflow as tf
import mediapipe as mp


# ============================================================
# PROJECT
# ============================================================

PROJECT = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        ".."
    )
)

MODEL = os.path.join(
    PROJECT,
    "models",
    "isl_20plus_final.tflite"
)

CLASSES = os.path.join(
    PROJECT,
    "models",
    "classes.txt"
)

MEAN_FILE = os.path.join(
    PROJECT,
    "models",
    "feature_mean.npy"
)

STD_FILE = os.path.join(
    PROJECT,
    "models",
    "feature_std.npy"
)


# ============================================================
# PUT YOUR ACTUAL INCLUDE VIDEO HERE
# ============================================================

VIDEO = r"D:\capstone\isl_conversational_model\data\videos\Days_and_Time\74. Tomorrow\MVI_4620.MOV"


# ============================================================
# SETTINGS
# ============================================================

SEQ_LEN = 40
RAW_FEATURES = 258
ENHANCED_FEATURES = 900


# ============================================================
# CHECK VIDEO
# ============================================================

if not os.path.isfile(VIDEO):

    print("\nVIDEO NOT FOUND:")
    print(VIDEO)

    print(
        "\nEdit VIDEO = r'...' at the top of this file "
        "and put the exact path to your INCLUDE video."
    )

    sys.exit(1)


# ============================================================
# LOAD CLASSES
# ============================================================

classes = []

with open(
    CLASSES,
    "r",
    encoding="utf-8"
) as f:

    for line in f:

        line = line.strip()

        if not line:
            continue

        _, label = line.split(
            "\t",
            1
        )

        classes.append(
            label
        )


# ============================================================
# LOAD NORMALIZATION
# ============================================================

feature_mean = np.load(
    MEAN_FILE
).astype(
    np.float32
)

feature_std = np.load(
    STD_FILE
).astype(
    np.float32
)

feature_std = np.where(
    feature_std < 1e-6,
    1.0,
    feature_std
).astype(
    np.float32
)


# ============================================================
# LOAD MODEL
# ============================================================

interpreter = tf.lite.Interpreter(
    model_path=MODEL
)

interpreter.allocate_tensors()

input_details = (
    interpreter.get_input_details()
)

output_details = (
    interpreter.get_output_details()
)


print(
    "\n========================================"
)

print(
    "INCLUDE DATASET VIDEO TEST"
)

print(
    "========================================"
)

print(
    "Video:",
    VIDEO
)

print(
    "Input:",
    input_details[0]["shape"]
)

print(
    "Output:",
    output_details[0]["shape"]
)

print(
    "Classes:",
    len(classes)
)


# ============================================================
# MEDIAPIPE
# ============================================================

mp_holistic = mp.solutions.holistic


# ============================================================
# 258 FEATURES
# ============================================================

def extract_raw_features(
    frame,
    holistic
):

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    result = holistic.process(
        rgb
    )

    features = []


    # --------------------------------------------------------
    # POSE = 132
    # --------------------------------------------------------

    if result.pose_landmarks:

        for lm in result.pose_landmarks.landmark:

            features.extend([
                lm.x,
                lm.y,
                lm.z,
                lm.visibility
            ])

    else:

        features.extend(
            [0.0] * 132
        )


    # --------------------------------------------------------
    # LEFT HAND = 63
    # --------------------------------------------------------

    if result.left_hand_landmarks:

        for lm in result.left_hand_landmarks.landmark:

            features.extend([
                lm.x,
                lm.y,
                lm.z
            ])

    else:

        features.extend(
            [0.0] * 63
        )


    # --------------------------------------------------------
    # RIGHT HAND = 63
    # --------------------------------------------------------

    if result.right_hand_landmarks:

        for lm in result.right_hand_landmarks.landmark:

            features.extend([
                lm.x,
                lm.y,
                lm.z
            ])

    else:

        features.extend(
            [0.0] * 63
        )


    features = np.asarray(
        features,
        dtype=np.float32
    )


    # ========================================================
    # SAME SHOULDER NORMALIZATION
    # ========================================================

    if len(features) == 258:

        left_shoulder = features[
            44:47
        ]

        right_shoulder = features[
            48:51
        ]

        center = (
            left_shoulder +
            right_shoulder
        ) / 2.0

        shoulder_distance = np.linalg.norm(
            left_shoulder -
            right_shoulder
        )

        if shoulder_distance > 1e-6:

            # POSE
            for i in range(33):

                base = i * 4

                features[
                    base:base + 3
                ] = (
                    features[
                        base:base + 3
                    ]
                    - center
                ) / shoulder_distance


            # LEFT HAND
            for i in range(21):

                base = 132 + i * 3

                features[
                    base:base + 3
                ] = (
                    features[
                        base:base + 3
                    ]
                    - center
                ) / shoulder_distance


            # RIGHT HAND
            for i in range(21):

                base = 195 + i * 3

                features[
                    base:base + 3
                ] = (
                    features[
                        base:base + 3
                    ]
                    - center
                ) / shoulder_distance


    return features


# ============================================================
# READ VIDEO
# ============================================================

cap = cv2.VideoCapture(
    VIDEO
)

if not cap.isOpened():

    raise RuntimeError(
        "Could not open video."
    )


total_frames = int(
    cap.get(
        cv2.CAP_PROP_FRAME_COUNT
    )
)

fps = cap.get(
    cv2.CAP_PROP_FPS
)

duration = (
    total_frames / fps
    if fps > 0
    else 0
)


print(
    "\nFrames:",
    total_frames
)

print(
    "FPS:",
    fps
)

print(
    "Duration:",
    duration,
    "seconds"
)


# ============================================================
# SAMPLE EXACTLY 40 FRAMES
# ============================================================

indices = np.linspace(
    0,
    max(
        total_frames - 1,
        0
    ),
    SEQ_LEN
).astype(int)

index_set = set(
    indices.tolist()
)


raw_sequence = []

current = 0


with mp_holistic.Holistic(

    static_image_mode=False,

    model_complexity=1,

    refine_face_landmarks=False,

    min_detection_confidence=0.5,

    min_tracking_confidence=0.5

) as holistic:

    while True:

        ok, frame = cap.read()

        if not ok:
            break


        if current in index_set:

            features = extract_raw_features(
                frame,
                holistic
            )

            raw_sequence.append(
                features
            )


        current += 1

        if current > indices[-1]:
            break


cap.release()


# ============================================================
# CHECK
# ============================================================

raw_sequence = np.asarray(
    raw_sequence,
    dtype=np.float32
)


print(
    "\nRaw sequence:",
    raw_sequence.shape
)


if raw_sequence.shape != (
    40,
    258
):

    raise RuntimeError(
        f"Wrong raw shape: "
        f"{raw_sequence.shape}"
    )


# ============================================================
# 258 → 900
# ============================================================

X = raw_sequence


# Velocity
velocity = np.diff(
    X,
    axis=0,
    prepend=X[:1]
)


# Acceleration
acceleration = np.diff(
    velocity,
    axis=0,
    prepend=velocity[:1]
)


# Left hand
left_hand = X[
    :,
    132:195
].reshape(
    40,
    21,
    3
)


# Right hand
right_hand = X[
    :,
    195:258
].reshape(
    40,
    21,
    3
)


# Wrist relative
left_relative = (
    left_hand -
    left_hand[:, 0:1, :]
).reshape(
    40,
    63
)


right_relative = (
    right_hand -
    right_hand[:, 0:1, :]
).reshape(
    40,
    63
)


# Combine
enhanced = np.concatenate(
    [
        X,
        velocity,
        acceleration,
        left_relative,
        right_relative
    ],
    axis=1
)


print(
    "Enhanced:",
    enhanced.shape
)


if enhanced.shape != (
    40,
    900
):

    raise RuntimeError(
        f"Wrong enhanced shape: "
        f"{enhanced.shape}"
    )


# ============================================================
# STANDARDIZE
# ============================================================

enhanced = (
    enhanced -
    feature_mean
) / feature_std


enhanced = np.clip(
    enhanced,
    -6,
    6
).astype(
    np.float32
)


# ============================================================
# INFERENCE
# ============================================================

input_data = np.expand_dims(
    enhanced,
    axis=0
)


interpreter.set_tensor(
    input_details[0]["index"],
    input_data
)

interpreter.invoke()


probabilities = (
    interpreter
    .get_tensor(
        output_details[0]["index"]
    )[0]
)


# ============================================================
# TOP PREDICTIONS
# ============================================================

top_ids = np.argsort(
    probabilities
)[::-1][:5]


print(
    "\n========================================"
)

print(
    "PREDICTION"
)

print(
    "========================================"
)

for rank, idx in enumerate(
    top_ids,
    1
):

    print(
        f"{rank}. "
        f"{classes[idx]:20s}"
        f" {probabilities[idx]:.2%}"
    )


predicted_id = int(
    top_ids[0]
)

predicted_label = classes[
    predicted_id
]

confidence = float(
    probabilities[
        predicted_id
    ]
)


print(
    "\nPredicted:",
    predicted_label
)

print(
    f"Confidence: {confidence:.2%}"
)


# ============================================================
# EXPECTED LABEL FROM FILENAME/PATH
# ============================================================

expected_label = None

# Find a class name contained in the video path
video_lower = VIDEO.lower()

for c in classes:

    if c.lower() in video_lower:

        expected_label = c

        break


if expected_label:

    print(
        "Expected:",
        expected_label
    )

    print(
        "CORRECT:"
        if predicted_label.lower()
        == expected_label.lower()
        else "INCORRECT"
    )