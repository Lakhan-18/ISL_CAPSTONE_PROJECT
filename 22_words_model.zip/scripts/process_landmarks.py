import os
import cv2
import numpy as np
import pandas as pd
import mediapipe as mp

from tqdm import tqdm


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        ".."
    )
)

VIDEO_ROOT = os.path.join(
    PROJECT,
    "data",
    "videos"
)

META_ROOT = os.path.join(
    PROJECT,
    "metadata"
)

LANDMARK_ROOT = os.path.join(
    PROJECT,
    "data",
    "landmarks"
)

os.makedirs(
    LANDMARK_ROOT,
    exist_ok=True
)


# ============================================================
# SETTINGS
# ============================================================

SEQ_LEN = 40
FEATURES = 258


# ============================================================
# MEDIAPIPE
# ============================================================

mp_holistic = mp.solutions.holistic


# ============================================================
# FRAME → 258 FEATURES
#
# Pose       = 33 × 4 = 132
# Left hand  = 21 × 3 = 63
# Right hand = 21 × 3 = 63
#
# TOTAL = 258
# ============================================================

def extract_frame_features(
    frame,
    holistic
):

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    result = holistic.process(
        rgb
    )

    features = []


    # --------------------------------------------------------
    # POSE
    # --------------------------------------------------------

    if result.pose_landmarks:

        for lm in result.pose_landmarks.landmark:

            features.extend([
                lm.x,
                lm.y,
                lm.z,
                lm.visibility
            ])

    else:

        features.extend(
            [0.0] * 132
        )


    # --------------------------------------------------------
    # LEFT HAND
    # --------------------------------------------------------

    if result.left_hand_landmarks:

        for lm in result.left_hand_landmarks.landmark:

            features.extend([
                lm.x,
                lm.y,
                lm.z
            ])

    else:

        features.extend(
            [0.0] * 63
        )


    # --------------------------------------------------------
    # RIGHT HAND
    # --------------------------------------------------------

    if result.right_hand_landmarks:

        for lm in result.right_hand_landmarks.landmark:

            features.extend([
                lm.x,
                lm.y,
                lm.z
            ])

    else:

        features.extend(
            [0.0] * 63
        )


    features = np.asarray(
        features,
        dtype=np.float32
    )


    # ========================================================
    # BODY-CENTERED NORMALIZATION
    # ========================================================

    if len(features) == FEATURES:

        # Pose landmark 11 = left shoulder
        left_shoulder = features[
            44:47
        ]

        # Pose landmark 12 = right shoulder
        right_shoulder = features[
            48:51
        ]

        center = (
            left_shoulder +
            right_shoulder
        ) / 2.0

        shoulder_distance = np.linalg.norm(
            left_shoulder -
            right_shoulder
        )

        if shoulder_distance > 1e-6:

            # ----------------------------
            # POSE
            # ----------------------------

            for i in range(33):

                base = i * 4

                features[
                    base:base + 3
                ] = (
                    features[
                        base:base + 3
                    ] - center
                ) / shoulder_distance


            # ----------------------------
            # LEFT HAND
            # ----------------------------

            for i in range(21):

                base = 132 + i * 3

                features[
                    base:base + 3
                ] = (
                    features[
                        base:base + 3
                    ] - center
                ) / shoulder_distance


            # ----------------------------
            # RIGHT HAND
            # ----------------------------

            for i in range(21):

                base = 195 + i * 3

                features[
                    base:base + 3
                ] = (
                    features[
                        base:base + 3
                    ] - center
                ) / shoulder_distance


    return features


# ============================================================
# VIDEO → 40 × 258
# ============================================================

def video_to_sequence(
    video_path
):

    cap = cv2.VideoCapture(
        video_path
    )

    if not cap.isOpened():

        return None


    total_frames = int(
        cap.get(
            cv2.CAP_PROP_FRAME_COUNT
        )
    )

    if total_frames <= 0:

        cap.release()

        return None


    # --------------------------------------------------------
    # 40 UNIFORM FRAME INDICES
    # --------------------------------------------------------

    sample_indices = np.linspace(
        0,
        total_frames - 1,
        SEQ_LEN
    ).astype(int)

    sample_set = set(
        sample_indices.tolist()
    )

    sequence = []

    current_index = 0


    with mp_holistic.Holistic(
        static_image_mode=False,
        model_complexity=1,
        refine_face_landmarks=False,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
    ) as holistic:


        while True:

            ok, frame = cap.read()

            if not ok:
                break


            if current_index in sample_set:

                features = extract_frame_features(
                    frame,
                    holistic
                )

                if len(features) == FEATURES:

                    sequence.append(
                        features
                    )


            current_index += 1


            if current_index > sample_indices[-1]:
                break


    cap.release()


    if not sequence:

        return None


    # --------------------------------------------------------
    # PAD IF A FEW FRAMES WERE MISSED
    # --------------------------------------------------------

    while len(sequence) < SEQ_LEN:

        sequence.append(
            sequence[-1].copy()
        )


    sequence = np.asarray(
        sequence[:SEQ_LEN],
        dtype=np.float32
    )


    if sequence.shape != (
        SEQ_LEN,
        FEATURES
    ):

        return None


    return sequence


# ============================================================
# PROCESS ONE SPLIT
# ============================================================

def process_split(
    df,
    split
):

    output_dir = os.path.join(
        LANDMARK_ROOT,
        split
    )

    os.makedirs(
        output_dir,
        exist_ok=True
    )

    records = []

    missing = 0
    failed = 0


    print(
        f"\n========== {split.upper()} =========="
    )


    for idx, row in tqdm(
        df.iterrows(),
        total=len(df),
        desc=split
    ):

        video_path = os.path.join(
            VIDEO_ROOT,
            str(row["video_path"])
        )

        if not os.path.isfile(
            video_path
        ):

            missing += 1
            continue


        output_path = os.path.join(
            output_dir,
            f"{idx}.npy"
        )


        # ----------------------------------------------------
        # REUSE EXISTING VALID FILE
        # ----------------------------------------------------

        if os.path.isfile(
            output_path
        ):

            try:

                arr = np.load(
                    output_path
                )

                if arr.shape == (
                    SEQ_LEN,
                    FEATURES
                ):

                    records.append({
                        "path":
                            output_path,

                        "label":
                            row["clean_label"],

                        "video_path":
                            row["video_path"]
                    })

                    continue

            except:

                pass


        # ----------------------------------------------------
        # PROCESS VIDEO
        # ----------------------------------------------------

        try:

            sequence = video_to_sequence(
                video_path
            )

            if sequence is None:

                failed += 1
                continue


            np.save(
                output_path,
                sequence
            )


            records.append({
                "path":
                    output_path,

                "label":
                    row["clean_label"],

                "video_path":
                    row["video_path"]
            })


        except Exception as e:

            failed += 1

            print(
                "\nERROR:",
                video_path,
                e
            )


    result = pd.DataFrame(
        records
    )


    if len(result) == 0:

        raise RuntimeError(
            f"{split} produced ZERO sequences.\n"
            f"Missing videos: {missing}\n"
            f"Failed videos: {failed}"
        )


    output_csv = os.path.join(
        META_ROOT,
        f"{split}_processed.csv"
    )

    result.to_csv(
        output_csv,
        index=False
    )


    print(
        f"\n{split} processed:",
        len(result)
    )

    print(
        f"{split} missing:",
        missing
    )

    print(
        f"{split} failed:",
        failed
    )

    print(
        f"{split} classes:",
        result["label"].nunique()
    )


    return result


# ============================================================
# LOAD METADATA
# ============================================================

train_df = pd.read_csv(
    os.path.join(
        META_ROOT,
        "train_24.csv"
    )
)

val_df = pd.read_csv(
    os.path.join(
        META_ROOT,
        "val_24.csv"
    )
)

test_df = pd.read_csv(
    os.path.join(
        META_ROOT,
        "test_24.csv"
    )
)


print(
    "Metadata loaded:"
)

print(
    "Train:",
    len(train_df)
)

print(
    "Val:",
    len(val_df)
)

print(
    "Test:",
    len(test_df)
)


# ============================================================
# PROCESS
# ============================================================

train_processed = process_split(
    train_df,
    "train"
)

val_processed = process_split(
    val_df,
    "val"
)

test_processed = process_split(
    test_df,
    "test"
)


# ============================================================
# FINAL CHECK
# ============================================================

print(
    "\n========================================"
)

print(
    "PREPROCESSING COMPLETE"
)

print(
    "========================================"
)

print(
    "Train:",
    train_processed.shape
)

print(
    "Val:",
    val_processed.shape
)

print(
    "Test:",
    test_processed.shape
)