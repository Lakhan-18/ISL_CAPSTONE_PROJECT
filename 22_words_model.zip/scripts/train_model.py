# ============================================================
# train_model.py
#
# BETTER 20+ CLASS ISL PROTOTYPE
#
# Existing landmarks:
#   40 frames x 258 features
#
# Enhanced features:
#   original landmarks
#   + velocity
#   + acceleration
#   + hand-relative coordinates
#
# Model:
#   Temporal CNN + Bidirectional GRU
#
# Selection:
#   validation set ONLY
#
# Final:
#   one held-out TEST evaluation
# ============================================================

import os
import json
import random

import numpy as np
import pandas as pd
import tensorflow as tf

from sklearn.preprocessing import LabelEncoder
from sklearn.utils.class_weight import compute_class_weight
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

from tensorflow.keras import (
    layers,
    models,
    callbacks,
    regularizers
)


# ============================================================
# REPRODUCIBILITY
# ============================================================

SEED = 42

random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        ".."
    )
)

META_ROOT = os.path.join(
    PROJECT,
    "metadata"
)

LANDMARK_ROOT = os.path.join(
    PROJECT,
    "data",
    "landmarks"
)

MODEL_ROOT = os.path.join(
    PROJECT,
    "models"
)

RESULT_ROOT = os.path.join(
    PROJECT,
    "results"
)

os.makedirs(
    MODEL_ROOT,
    exist_ok=True
)

os.makedirs(
    RESULT_ROOT,
    exist_ok=True
)


# ============================================================
# SETTINGS
# ============================================================

SEQ_LEN = 40
BASE_FEATURES = 258

MIN_CLASSES = 20

MIN_TRAIN_PER_CLASS = 8
MIN_TEST_PER_CLASS = 1

BATCH_SIZE = 16
EPOCHS = 80


# ============================================================
# CHECK FILES
# ============================================================

for split in [
    "train",
    "val",
    "test"
]:

    path = os.path.join(
        META_ROOT,
        f"{split}_processed.csv"
    )

    if not os.path.isfile(path):

        raise FileNotFoundError(
            f"Missing:\n{path}\n"
            "Run preprocess_landmarks.py first."
        )


# ============================================================
# LOAD .NPY DATA
# ============================================================

def load_split(
    split
):

    csv_path = os.path.join(
        META_ROOT,
        f"{split}_processed.csv"
    )

    df = pd.read_csv(
        csv_path
    )

    X = []
    labels = []


    for _, row in df.iterrows():

        path = str(
            row["path"]
        )

        if not os.path.isfile(path):
            continue

        try:

            arr = np.load(
                path
            )

            if arr.shape != (
                SEQ_LEN,
                BASE_FEATURES
            ):

                continue

            X.append(
                arr.astype(
                    np.float32
                )
            )

            labels.append(
                str(row["label"]).lower()
            )

        except Exception:

            continue


    if not X:

        raise RuntimeError(
            f"No valid arrays found for {split}"
        )


    return (
        np.stack(X),
        np.asarray(labels)
    )


X_train_raw, labels_train = load_split(
    "train"
)

X_val_raw, labels_val = load_split(
    "val"
)

X_test_raw, labels_test = load_split(
    "test"
)


print("\nRAW DATA")

print(
    "Train:",
    X_train_raw.shape
)

print(
    "Val  :",
    X_val_raw.shape
)

print(
    "Test :",
    X_test_raw.shape
)


# ============================================================
# CLASS COUNTS
# ============================================================

train_counts = (
    pd.Series(labels_train)
    .value_counts()
)

val_counts = (
    pd.Series(labels_val)
    .value_counts()
)

test_counts = (
    pd.Series(labels_test)
    .value_counts()
)


print(
    "\nTRAIN CLASS COUNTS:"
)

print(
    train_counts.sort_values(
        ascending=False
    )
)


# ============================================================
# SELECT BEST-SUPPORTED CLASSES
#
# We choose the strongest 20+ classes based on TRAIN support.
# This avoids wasting the prototype on classes with virtually
# no training examples.
# ============================================================

candidate_classes = [

    c for c in train_counts.index

    if train_counts[c]
    >= MIN_TRAIN_PER_CLASS
]


# Require class to appear in validation
candidate_classes = [

    c for c in candidate_classes

    if val_counts.get(c, 0) >= 1
]


# Require class to appear in test
candidate_classes = [

    c for c in candidate_classes

    if test_counts.get(c, 0)
    >= MIN_TEST_PER_CLASS
]


candidate_classes = sorted(
    candidate_classes,
    key=lambda c:
        train_counts[c],
    reverse=True
)


if len(candidate_classes) < MIN_CLASSES:

    raise RuntimeError(
        f"Only {len(candidate_classes)} "
        f"classes have sufficient support. "
        f"Need at least {MIN_CLASSES}."
    )


SELECTED_CLASSES = candidate_classes[
    :max(
        MIN_CLASSES,
        min(
            22,
            len(candidate_classes)
        )
    )
]


print(
    "\n========================================"
)

print(
    "SELECTED PROTOTYPE CLASSES"
)

print(
    "========================================"
)

print(
    "Number:",
    len(SELECTED_CLASSES)
)

for i, c in enumerate(
    SELECTED_CLASSES,
    1
):

    print(
        f"{i:2d}. {c:20s}"
        f" train={train_counts[c]:3d}"
        f" val={val_counts.get(c,0):3d}"
        f" test={test_counts.get(c,0):3d}"
    )


# ============================================================
# FILTER SPLITS
# ============================================================

def filter_split(
    X,
    labels
):

    mask = np.isin(
        labels,
        SELECTED_CLASSES
    )

    return (
        X[mask],
        labels[mask]
    )


X_train_raw, labels_train = filter_split(
    X_train_raw,
    labels_train
)

X_val_raw, labels_val = filter_split(
    X_val_raw,
    labels_val
)

X_test_raw, labels_test = filter_split(
    X_test_raw,
    labels_test
)


# ============================================================
# FEATURE ENGINEERING
# ============================================================

def enhance_features(
    X
):

    X = X.astype(
        np.float32
    )

    # --------------------------------------------------------
    # VELOCITY
    # --------------------------------------------------------

    velocity = np.diff(
        X,
        axis=1,
        prepend=X[:, :1, :]
    )


    # --------------------------------------------------------
    # ACCELERATION
    # --------------------------------------------------------

    acceleration = np.diff(
        velocity,
        axis=1,
        prepend=velocity[:, :1, :]
    )


    # --------------------------------------------------------
    # HAND-RELATIVE FEATURES
    #
    # Left hand:
    #   132..194
    #
    # Right hand:
    #   195..257
    #
    # Wrist landmark = hand landmark 0
    # --------------------------------------------------------

    left_hand = X[
        :,
        :,
        132:195
    ].copy()

    right_hand = X[
        :,
        :,
        195:258
    ].copy()


    # Reshape:
    # 21 landmarks × 3 coordinates

    left_hand = left_hand.reshape(
        X.shape[0],
        X.shape[1],
        21,
        3
    )

    right_hand = right_hand.reshape(
        X.shape[0],
        X.shape[1],
        21,
        3
    )


    # Wrist-centered
    left_wrist = (
        left_hand[:, :, 0:1, :]
    )

    right_wrist = (
        right_hand[:, :, 0:1, :]
    )


    left_relative = (
        left_hand -
        left_wrist
    )

    right_relative = (
        right_hand -
        right_wrist
    )


    left_relative = left_relative.reshape(
        X.shape[0],
        X.shape[1],
        63
    )

    right_relative = right_relative.reshape(
        X.shape[0],
        X.shape[1],
        63
    )


    # --------------------------------------------------------
    # COMBINE
    # --------------------------------------------------------

    enhanced = np.concatenate(
        [
            X,
            velocity,
            acceleration,
            left_relative,
            right_relative
        ],
        axis=2
    )


    return enhanced.astype(
        np.float32
    )


X_train = enhance_features(
    X_train_raw
)

X_val = enhance_features(
    X_val_raw
)

X_test = enhance_features(
    X_test_raw
)


print(
    "\nENHANCED DATA"
)

print(
    "Train:",
    X_train.shape
)

print(
    "Val:",
    X_val.shape
)

print(
    "Test:",
    X_test.shape
)


# ============================================================
# EXPECTED:
#
# 258
# +258 velocity
# +258 acceleration
# +63 left-relative
# +63 right-relative
# =900
# ============================================================

INPUT_FEATURES = X_train.shape[2]

assert (
    INPUT_FEATURES == 900
)


# ============================================================
# LABEL ENCODING
# ============================================================

encoder = LabelEncoder()

encoder.fit(
    SELECTED_CLASSES
)

y_train = encoder.transform(
    labels_train
).astype(
    np.int32
)

y_val = encoder.transform(
    labels_val
).astype(
    np.int32
)

y_test = encoder.transform(
    labels_test
).astype(
    np.int32
)


NUM_CLASSES = len(
    encoder.classes_
)


# ============================================================
# STANDARDIZATION
#
# FIT ONLY ON TRAINING DATA
# ============================================================

train_mean = X_train.mean(
    axis=(0, 1)
)

train_std = X_train.std(
    axis=(0, 1)
)

train_std = np.where(
    train_std < 1e-6,
    1.0,
    train_std
)


X_train = (
    X_train -
    train_mean
) / train_std


X_val = (
    X_val -
    train_mean
) / train_std


X_test = (
    X_test -
    train_mean
) / train_std


# Prevent extreme values
X_train = np.clip(
    X_train,
    -6,
    6
)

X_val = np.clip(
    X_val,
    -6,
    6
)

X_test = np.clip(
    X_test,
    -6,
    6
)


# ============================================================
# AUGMENT TRAIN ONLY
# ============================================================

def augment(
    X,
    y
):

    rng = np.random.default_rng(
        SEED
    )

    X_list = [
        X
    ]

    y_list = [
        y
    ]


    # --------------------------------------------------------
    # SMALL GAUSSIAN NOISE
    # --------------------------------------------------------

    noise = rng.normal(
        0,
        0.025,
        X.shape
    ).astype(
        np.float32
    )

    X_list.append(
        X + noise
    )

    y_list.append(
        y
    )


    # --------------------------------------------------------
    # TEMPORAL SHIFT
    # --------------------------------------------------------

    shifted = np.roll(
        X,
        rng.integers(
            -2,
            3
        ),
        axis=1
    )

    X_list.append(
        shifted
    )

    y_list.append(
        y
    )


    return (
        np.concatenate(
            X_list,
            axis=0
        ),

        np.concatenate(
            y_list,
            axis=0
        )
    )


X_train_aug, y_train_aug = augment(
    X_train,
    y_train
)


print(
    "\nAugmented train:",
    X_train_aug.shape
)


# ============================================================
# CLASS WEIGHTS
# ============================================================

weights = compute_class_weight(
    class_weight="balanced",
    classes=np.unique(y_train),
    y=y_train
)

class_weights = {

    int(c): float(w)

    for c, w in zip(
        np.unique(y_train),
        weights
    )
}


# ============================================================
# MODEL
#
# Temporal CNN extracts local motion patterns.
# BiGRU learns the complete sign movement.
# ============================================================

def build_model():

    inp = layers.Input(
        shape=(
            SEQ_LEN,
            INPUT_FEATURES
        )
    )


    x = layers.Conv1D(
        96,
        kernel_size=5,
        padding="same",
        activation="relu"
    )(inp)


    x = layers.BatchNormalization()(x)

    x = layers.SpatialDropout1D(
        0.20
    )(x)


    x = layers.Conv1D(
        128,
        kernel_size=5,
        padding="same",
        activation="relu"
    )(x)


    x = layers.BatchNormalization()(x)


    x = layers.Bidirectional(
        layers.GRU(
            64,
            return_sequences=True,
            dropout=0.25,
            recurrent_dropout=0.0
        )
    )(x)


    # Attention-like pooling
    attention = layers.Dense(
        1,
        activation="tanh"
    )(x)


    attention = layers.Softmax(
        axis=1
    )(attention)


    x = layers.Multiply()(
        [
            x,
            attention
        ]
    )


    x = layers.GlobalAveragePooling1D()(
        x
    )


    x = layers.Dense(
        96,
        activation="relu",
        kernel_regularizer=
            regularizers.l2(
                1e-4
            )
    )(x)


    x = layers.Dropout(
        0.45
    )(x)


    out = layers.Dense(
        NUM_CLASSES,
        activation="softmax"
    )(x)


    return models.Model(
        inp,
        out
    )


model = build_model()


model.compile(

    optimizer=tf.keras.optimizers.Adam(
        learning_rate=3e-4
    ),

    loss=
        "sparse_categorical_crossentropy",

    metrics=[
        "accuracy"
    ]
)


print(
    "\n========================================"
)

print(
    "MODEL"
)

print(
    "========================================"
)

model.summary()


# ============================================================
# CALLBACKS
# ============================================================

best_path = os.path.join(
    MODEL_ROOT,
    "best_isl_20plus.keras"
)


callback_list = [

    callbacks.ModelCheckpoint(
        best_path,
        monitor="val_accuracy",
        mode="max",
        save_best_only=True,
        verbose=1
    ),

    callbacks.EarlyStopping(
        monitor="val_accuracy",
        mode="max",
        patience=12,
        restore_best_weights=True,
        verbose=1
    ),

    callbacks.ReduceLROnPlateau(
        monitor="val_loss",
        mode="min",
        factor=0.5,
        patience=4,
        min_lr=1e-6,
        verbose=1
    )
]


# ============================================================
# TRAIN
# ============================================================

print(
    "\n========================================"
)

print(
    "TRAINING"
)

print(
    "========================================"
)


history = model.fit(

    X_train_aug,
    y_train_aug,

    validation_data=(
        X_val,
        y_val
    ),

    epochs=EPOCHS,

    batch_size=BATCH_SIZE,

    class_weight=class_weights,

    callbacks=callback_list,

    shuffle=True,

    verbose=1
)


# ============================================================
# LOAD BEST MODEL
# ============================================================

best_model = tf.keras.models.load_model(
    best_path
)


# ============================================================
# FINAL TEST
# ============================================================

test_prob = best_model.predict(
    X_test,
    batch_size=BATCH_SIZE,
    verbose=1
)

test_pred = np.argmax(
    test_prob,
    axis=1
)


test_accuracy = accuracy_score(
    y_test,
    test_pred
)


# ============================================================
# REPORT
# ============================================================

print(
    "\n========================================"
)

print(
    "FINAL HELD-OUT TEST RESULT"
)

print(
    "========================================"
)

print(
    f"Classes : {NUM_CLASSES}"
)

print(
    f"Accuracy: "
    f"{test_accuracy * 100:.2f}%"
)


report = classification_report(
    y_test,
    test_pred,
    labels=np.arange(
        NUM_CLASSES
    ),
    target_names=
        encoder.classes_,
    zero_division=0
)


print(
    "\n",
    report
)


# ============================================================
# CONFUSION MATRIX
# ============================================================

cm = confusion_matrix(
    y_test,
    test_pred,
    labels=np.arange(
        NUM_CLASSES
    )
)

np.save(
    os.path.join(
        RESULT_ROOT,
        "confusion_matrix.npy"
    ),
    cm
)


with open(
    os.path.join(
        RESULT_ROOT,
        "classification_report.txt"
    ),
    "w",
    encoding="utf-8"
) as f:

    f.write(
        report
    )


# ============================================================
# SAVE CLASSES
# ============================================================

classes_path = os.path.join(
    MODEL_ROOT,
    "classes.txt"
)

with open(
    classes_path,
    "w",
    encoding="utf-8"
) as f:

    for i, label in enumerate(
        encoder.classes_
    ):

        f.write(
            f"{i}\t{label}\n"
        )


# ============================================================
# SAVE PREPROCESSING PARAMETERS
# ============================================================

np.save(
    os.path.join(
        MODEL_ROOT,
        "feature_mean.npy"
    ),
    train_mean
)

np.save(
    os.path.join(
        MODEL_ROOT,
        "feature_std.npy"
    ),
    train_std
)


preprocessing = {

    "sequence_length":
        SEQ_LEN,

    "base_features":
        258,

    "enhanced_features":
        900,

    "components": [
        "raw_258",
        "velocity_258",
        "acceleration_258",
        "left_hand_relative_63",
        "right_hand_relative_63"
    ],

    "standardization":
        "train_mean/train_std",

    "classes":
        encoder.classes_.tolist()
}


with open(
    os.path.join(
        MODEL_ROOT,
        "preprocessing.json"
    ),
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        preprocessing,
        f,
        indent=4
    )


# ============================================================
# SAVE FINAL KERAS MODEL
# ============================================================

keras_path = os.path.join(
    MODEL_ROOT,
    "isl_20plus_final.keras"
)

best_model.save(
    keras_path
)


# ============================================================
# TFLITE
# ============================================================

print(
    "\nConverting to TFLite..."
)


tflite_path = os.path.join(
    MODEL_ROOT,
    "isl_20plus_final.tflite"
)


converter = (
    tf.lite.TFLiteConverter
    .from_keras_model(
        best_model
    )
)


converter.target_spec.supported_ops = [

    tf.lite.OpsSet.TFLITE_BUILTINS,

    tf.lite.OpsSet.SELECT_TF_OPS

]

converter._experimental_lower_tensor_list_ops = False


tflite_model = converter.convert()


with open(
    tflite_path,
    "wb"
) as f:

    f.write(
        tflite_model
    )


# ============================================================
# VERIFY TFLITE
# ============================================================

interpreter = tf.lite.Interpreter(
    model_path=tflite_path
)

interpreter.allocate_tensors()


print(
    "\nTFLite input:",
    interpreter
    .get_input_details()[0]["shape"]
)

print(
    "TFLite output:",
    interpreter
    .get_output_details()[0]["shape"]
)


# ============================================================
# SAVE SUMMARY
# ============================================================

summary = {

    "classes":
        NUM_CLASSES,

    "test_accuracy":
        float(
            test_accuracy
        ),

    "test_accuracy_percent":
        float(
            test_accuracy * 100
        ),

    "train_samples":
        int(
            len(X_train)
        ),

    "validation_samples":
        int(
            len(X_val)
        ),

    "test_samples":
        int(
            len(X_test)
        ),

    "enhanced_input":
        [
            40,
            900
        ],

    "target_60_percent":
        bool(
            test_accuracy >= 0.60
        )
}


with open(
    os.path.join(
        RESULT_ROOT,
        "training_summary.json"
    ),
    "w"
) as f:

    json.dump(
        summary,
        f,
        indent=4
    )


# ============================================================
# FINAL MESSAGE
# ============================================================

print(
    "\n========================================"
)

print(
    "✅ TRAINING COMPLETE"
)

print(
    "========================================"
)

print(
    f"TEST ACCURACY: "
    f"{test_accuracy * 100:.2f}%"
)

print(
    f"CLASSES: {NUM_CLASSES}"
)

print(
    "\nModel:"
)

print(
    keras_path
)

print(
    "\nTFLite:"
)

print(
    tflite_path
)

print(
    "\nClasses:"
)

print(
    classes_path
)

if test_accuracy >= 0.60:

    print(
        "\n🎉 TARGET >= 60% ACHIEVED"
    )

else:

    print(
        "\n⚠️ 60% target NOT achieved."
    )

    print(
        "Do not alter the test set."
    )