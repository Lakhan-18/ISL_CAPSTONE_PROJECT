import os
import zipfile

# ============================================================
# USE THE CURRENT PROJECT DIRECTORY
# ============================================================

PROJECT = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        ".."
    )
)

ARCHIVE_DIR = os.path.join(
    PROJECT,
    "data",
    "archives"
)

VIDEO_DIR = os.path.join(
    PROJECT,
    "data",
    "videos"
)

os.makedirs(
    VIDEO_DIR,
    exist_ok=True
)

print("Project:")
print(PROJECT)

print("\nArchive directory:")
print(ARCHIVE_DIR)

print("\nVideo directory:")
print(VIDEO_DIR)


# ============================================================
# EXTRACT ALL ZIP FILES
# ============================================================

zip_files = [
    f
    for f in os.listdir(ARCHIVE_DIR)
    if f.lower().endswith(".zip")
]

print(
    "\nZIP files found:",
    len(zip_files)
)

for filename in sorted(zip_files):

    zip_path = os.path.join(
        ARCHIVE_DIR,
        filename
    )

    print(
        "\nExtracting:",
        filename
    )

    try:

        with zipfile.ZipFile(
            zip_path,
            "r"
        ) as z:

            bad = z.testzip()

            if bad is not None:

                print(
                    "❌ Corrupt ZIP:",
                    bad
                )

                continue

            z.extractall(
                VIDEO_DIR
            )

        print(
            "✅ Extracted"
        )

    except zipfile.BadZipFile:

        print(
            "❌ Invalid ZIP:",
            filename
        )


# ============================================================
# COUNT VIDEOS
# ============================================================

video_count = 0

for root, dirs, files in os.walk(
    VIDEO_DIR
):

    for f in files:

        if f.lower().endswith(
            (".mov", ".mp4")
        ):

            video_count += 1


print(
    "\n======================================"
)

print(
    "EXTRACTION COMPLETE"
)

print(
    "Total videos:",
    video_count
)

print(
    "======================================"
)


# ============================================================
# SHOW EXAMPLES
# ============================================================

shown = 0

print(
    "\nExample extracted videos:"
)

for root, dirs, files in os.walk(
    VIDEO_DIR
):

    for f in files:

        if f.lower().endswith(
            (".mov", ".mp4")
        ):

            print(
                os.path.relpath(
                    os.path.join(root, f),
                    VIDEO_DIR
                )
            )

            shown += 1

            if shown >= 10:
                break

    if shown >= 10:
        break