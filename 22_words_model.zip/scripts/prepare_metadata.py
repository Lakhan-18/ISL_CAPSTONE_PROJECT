import os
import re
import requests
import pandas as pd


# ============================================================
# PROJECT
# ============================================================

PROJECT = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        ".."
    )
)

META_DIR = os.path.join(
    PROJECT,
    "metadata"
)

os.makedirs(
    META_DIR,
    exist_ok=True
)


# ============================================================
# DOWNLOAD INCLUDE PARQUET METADATA
# ============================================================

BASE_URL = (
    "https://huggingface.co/datasets/"
    "ai4bharat/INCLUDE/resolve/"
    "refs%2Fconvert%2Fparquet/default"
)


def load_split(split):

    url = (
        f"{BASE_URL}/"
        f"{split}/0000.parquet"
    )

    print(
        f"Loading {split}..."
    )

    response = requests.get(
        url,
        timeout=120
    )

    response.raise_for_status()

    temp_path = os.path.join(
        META_DIR,
        f"include_{split}.parquet"
    )

    with open(
        temp_path,
        "wb"
    ) as f:

        f.write(
            response.content
        )

    return pd.read_parquet(
        temp_path
    )


train = load_split("train")
val   = load_split("val")
test  = load_split("test")


# ============================================================
# CLEAN LABEL
# ============================================================

def clean_label(x):

    return re.sub(
        r"^\s*\d+\.\s*",
        "",
        str(x)
    ).strip().lower()


for df in [
    train,
    val,
    test
]:

    df["clean_label"] = (
        df["label"]
        .apply(clean_label)
    )


# ============================================================
# 24-CLASS PROTOTYPE
# Based on your downloaded ZIPs
# ============================================================

TARGET_WORDS = [

    # -------------------------
    # Greetings
    # -------------------------

    "hello",
    "how are you",
    "alright",
    "good morning",
    "good afternoon",
    "good evening",
    "good night",
    "thank you",
    "pleased",

    # -------------------------
    # Days / Time
    # -------------------------

    "sunday",
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
    "today",
    "tomorrow",
    "yesterday",
    "week",
    "month",
    "year",
    "hour",
    "minute"
]


# ============================================================
# CHECK
# ============================================================

available = (
    set(train["clean_label"])
    |
    set(val["clean_label"])
    |
    set(test["clean_label"])
)

missing = [
    w
    for w in TARGET_WORDS
    if w not in available
]

print(
    "\nMissing target classes:"
)

print(
    missing
)

if missing:

    raise ValueError(
        "Some target labels are missing."
    )


# ============================================================
# FILTER
# ============================================================

train_sub = train[
    train["clean_label"].isin(
        TARGET_WORDS
    )
].copy()

val_sub = val[
    val["clean_label"].isin(
        TARGET_WORDS
    )
].copy()

test_sub = test[
    test["clean_label"].isin(
        TARGET_WORDS
    )
].copy()


# ============================================================
# SAVE
# ============================================================

train_sub.to_csv(
    os.path.join(
        META_DIR,
        "train_24.csv"
    ),
    index=False
)

val_sub.to_csv(
    os.path.join(
        META_DIR,
        "val_24.csv"
    ),
    index=False
)

test_sub.to_csv(
    os.path.join(
        META_DIR,
        "test_24.csv"
    ),
    index=False
)


# ============================================================
# SUMMARY
# ============================================================

print(
    "\n======================================"
)

print(
    "METADATA READY"
)

print(
    "======================================"
)

print(
    "Classes:",
    len(TARGET_WORDS)
)

print(
    "Train:",
    len(train_sub)
)

print(
    "Val:",
    len(val_sub)
)

print(
    "Test:",
    len(test_sub)
)

print(
    "\nTrain distribution:"
)

print(
    train_sub[
        "clean_label"
    ].value_counts().sort_index()
)